﻿namespace ANDREANI_PASTICCERIA
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Button btnAggiornaOrdini;
        private System.Windows.Forms.Button btnSpesa;
        private System.Windows.Forms.Button btnCucinato;
        private System.Windows.Forms.Button btnAggiungi;
        private System.Windows.Forms.ListBox listBoxOrdine;
        private System.Windows.Forms.ListBox listBoxSpesa;
        private System.Windows.Forms.Label lblOrders;
        private System.Windows.Forms.Label lblShopping;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblOrders = new Label();
            listBoxOrdine = new ListBox();
            lblShopping = new Label();
            listBoxSpesa = new ListBox();
            btnAggiornaOrdini = new Button();
            btnCucinato = new Button();
            btnSpesa = new Button();
            btnAggiungi = new Button();
            SuspendLayout();
            // 
            // lblOrders
            // 
            lblOrders.AutoSize = true;
            lblOrders.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblOrders.ForeColor = Color.FromArgb(60, 60, 90);
            lblOrders.Location = new Point(25, 20);
            lblOrders.Name = "lblOrders";
            lblOrders.Size = new Size(144, 21);
            lblOrders.TabIndex = 0;
            lblOrders.Text = "📦 Ordini Ricevuti";
            // 
            // listBoxOrdine
            // 
            listBoxOrdine.BackColor = Color.White;
            listBoxOrdine.BorderStyle = BorderStyle.FixedSingle;
            listBoxOrdine.Font = new Font("Segoe UI", 10F);
            listBoxOrdine.ForeColor = Color.FromArgb(40, 40, 60);
            listBoxOrdine.ItemHeight = 17;
            listBoxOrdine.Location = new Point(25, 55);
            listBoxOrdine.Name = "listBoxOrdine";
            listBoxOrdine.Size = new Size(330, 308);
            listBoxOrdine.TabIndex = 2;
            // 
            // lblShopping
            // 
            lblShopping.AutoSize = true;
            lblShopping.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblShopping.ForeColor = Color.FromArgb(60, 60, 90);
            lblShopping.Location = new Point(390, 20);
            lblShopping.Name = "lblShopping";
            lblShopping.Size = new Size(183, 21);
            lblShopping.TabIndex = 1;
            lblShopping.Text = "\U0001f6d2 Pianificazione Spesa";
            // 
            // listBoxSpesa
            // 
            listBoxSpesa.BackColor = Color.White;
            listBoxSpesa.BorderStyle = BorderStyle.FixedSingle;
            listBoxSpesa.Font = new Font("Segoe UI", 10F);
            listBoxSpesa.ForeColor = Color.FromArgb(40, 40, 60);
            listBoxSpesa.ItemHeight = 17;
            listBoxSpesa.Location = new Point(390, 55);
            listBoxSpesa.Name = "listBoxSpesa";
            listBoxSpesa.Size = new Size(330, 308);
            listBoxSpesa.TabIndex = 3;
            // 
            // btnAggiornaOrdini
            // 
            btnAggiornaOrdini.BackColor = Color.FromArgb(230, 230, 255);
            btnAggiornaOrdini.FlatAppearance.BorderSize = 0;
            btnAggiornaOrdini.FlatStyle = FlatStyle.Flat;
            btnAggiornaOrdini.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnAggiornaOrdini.Location = new Point(25, 380);
            btnAggiornaOrdini.Name = "btnAggiornaOrdini";
            btnAggiornaOrdini.Size = new Size(160, 42);
            btnAggiornaOrdini.TabIndex = 4;
            btnAggiornaOrdini.Text = "🔄 Carica Ordini";
            btnAggiornaOrdini.UseVisualStyleBackColor = false;
            btnAggiornaOrdini.Click += btnAggiornaOrdini_Click;
            // 
            // btnCucinato
            // 
            btnCucinato.BackColor = Color.FromArgb(200, 220, 255);
            btnCucinato.FlatAppearance.BorderSize = 0;
            btnCucinato.FlatStyle = FlatStyle.Flat;
            btnCucinato.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnCucinato.Location = new Point(195, 380);
            btnCucinato.Name = "btnCucinato";
            btnCucinato.Size = new Size(160, 42);
            btnCucinato.TabIndex = 5;
            btnCucinato.Text = "✔ Ordine Pronto";
            btnCucinato.UseVisualStyleBackColor = false;
            btnCucinato.Click += btnCucinato_Click;
            // 
            // btnSpesa
            // 
            btnSpesa.BackColor = Color.FromArgb(230, 230, 255);
            btnSpesa.FlatAppearance.BorderSize = 0;
            btnSpesa.FlatStyle = FlatStyle.Flat;
            btnSpesa.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnSpesa.Location = new Point(390, 380);
            btnSpesa.Name = "btnSpesa";
            btnSpesa.Size = new Size(160, 42);
            btnSpesa.TabIndex = 6;
            btnSpesa.Text = "📋 Analizza Spesa";
            btnSpesa.UseVisualStyleBackColor = false;
            btnSpesa.Click += btnSpesa_Click;
            // 
            // btnAggiungi
            // 
            btnAggiungi.BackColor = Color.FromArgb(200, 255, 200);
            btnAggiungi.FlatAppearance.BorderSize = 0;
            btnAggiungi.FlatStyle = FlatStyle.Flat;
            btnAggiungi.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnAggiungi.Location = new Point(560, 380);
            btnAggiungi.Name = "btnAggiungi";
            btnAggiungi.Size = new Size(160, 42);
            btnAggiungi.TabIndex = 7;
            btnAggiungi.Text = "➕ Inserisci Scorta";
            btnAggiungi.UseVisualStyleBackColor = false;
            btnAggiungi.Click += btnAggiungi_Click;
            // 
            // Form1
            // 
            BackColor = Color.FromArgb(245, 245, 255);
            ClientSize = new Size(760, 460);
            Controls.Add(lblOrders);
            Controls.Add(lblShopping);
            Controls.Add(listBoxOrdine);
            Controls.Add(listBoxSpesa);
            Controls.Add(btnAggiornaOrdini);
            Controls.Add(btnCucinato);
            Controls.Add(btnSpesa);
            Controls.Add(btnAggiungi);
            Font = new Font("Segoe UI", 10F);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            Text = "Pasticceria Ciccio – Gestione Ordini 2.0";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
