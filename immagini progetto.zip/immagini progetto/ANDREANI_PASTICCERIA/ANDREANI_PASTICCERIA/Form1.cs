using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace ANDREANI_PASTICCERIA
{
    public partial class Form1 : Form
    {
        readonly string fileRicette = "ricette.txt";
        readonly string fileDispensa = "dispensa.txt";

        List<string> ricette = new();
        List<string> dispensa = new();
        Dictionary<string, int> ordine = new();

        FileSystemWatcher? watcher;

        public Form1()
        {
            InitializeComponent();

            InizializzaFile();
            CaricaDati();
            SetupWatcher();

            LeggiOrdine();
        }

        // ============================
        // FILE DI BASE
        // ============================
        void InizializzaFile()
        {
            if (!File.Exists(fileRicette))
            {
                File.WriteAllLines(fileRicette, new[]
                {
                    "Tiramis�. Ingredienti: mascarpone, uova, zucchero, savoiardi, caff�, cacao. Preparazione: ...",
                    "Cheesecake. Ingredienti: biscotti, burro, formaggio spalmabile, zucchero, panna. Preparazione: ...",
                    "Cannoli. Ingredienti: ricotta, zucchero, cannoli, cioccolato, canditi. Preparazione: ...",
                    "Torta al Cioccolato. Ingredienti: farina, zucchero, uova, cacao, burro, lievito. Preparazione: ...",
                    "Millefoglie. Ingredienti: pasta sfoglia, crema pasticcera, zucchero a velo. Preparazione: ...",
                    "Profiteroles. Ingredienti: bign�, panna, cioccolato, zucchero, burro. Preparazione: ...",
                    "Gelato. Ingredienti: latte, panna, zucchero, tuorli. Preparazione: ...",
                    "Crostata. Ingredienti: farina, burro, zucchero, uova, marmellata. Preparazione: ...",
                    "Pan di Spagna. Ingredienti: farina, zucchero, uova, lievito. Preparazione: ...",
                    "Bavarese. Ingredienti: panna, latte, zucchero, gelatina, tuorli. Preparazione: ..."
                });
            }

            if (!File.Exists(fileDispensa))
            {
                File.WriteAllLines(fileDispensa, new[]
                {
                    "uova",
                    "farina",
                    "burro",
                    "zucchero",
                    "latte"
                });
            }
        }

        void CaricaDati()
        {
            ricette = File.ReadAllLines(fileRicette).ToList();

            dispensa = File.ReadAllLines(fileDispensa)
                .Select(x => x.Trim().ToLower())
                .Where(x => x.Length > 0)
                .ToList();
        }

        // ============================
        // FILESYSTEM WATCHER
        // ============================
        void SetupWatcher()
        {
            string path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "Downloads"
            );

            watcher = new FileSystemWatcher(path);
            watcher.Filter = "*.txt";
            watcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size;

            watcher.Created += OnFileChanged;
            watcher.Changed += OnFileChanged;
            watcher.Renamed += OnFileChanged;

            watcher.EnableRaisingEvents = true;
        }

        void OnFileChanged(object sender, FileSystemEventArgs e)
        {
            try
            {
                System.Threading.Thread.Sleep(800);

                this.Invoke((MethodInvoker)delegate
                {
                    LeggiOrdine();
                });
            }
            catch { }
        }

        // ============================
        // LETTURA ORDINI
        // ============================
        void LeggiOrdine()
        {
            string path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "Downloads"
            );

            ordine.Clear();
            listBoxOrdine.Items.Clear();

            var file = Directory.GetFiles(path)
                .Where(f => Path.GetFileName(f).ToLower().Contains("ordine")
                         && f.ToLower().EndsWith(".txt"))
                .OrderByDescending(File.GetLastWriteTime)
                .FirstOrDefault();

            if (file == null)
                return;

            string[] righe;

            try
            {
                righe = File.ReadAllLines(file);
            }
            catch
            {
                MessageBox.Show("Errore lettura file ordine");
                return;
            }

            foreach (var riga in righe)
            {
                if (string.IsNullOrWhiteSpace(riga))
                    continue;

                string r = riga.ToLower().Trim();

                string nome = r;
                int qta = 1;

                var parts = r.Split(new[] { 'x', '-', ':', ' ' }, StringSplitOptions.RemoveEmptyEntries);

                if (parts.Length >= 2 && int.TryParse(parts.Last(), out int n))
                {
                    qta = n;
                    nome = string.Join(" ", parts.Take(parts.Length - 1));
                }

                nome = nome.Trim();

                if (ordine.ContainsKey(nome))
                    ordine[nome] += qta;
                else
                    ordine[nome] = qta;
            }

            AggiornaUI();
        }

        void AggiornaUI()
        {
            listBoxOrdine.Items.Clear();

            foreach (var o in ordine)
                listBoxOrdine.Items.Add($"{o.Key} x{o.Value}");
        }

        // ============================
        // LISTA DELLA SPESA
        // ============================
        private void btnSpesa_Click(object sender, EventArgs e)
        {
            listBoxSpesa.Items.Clear();

            HashSet<string> spesa = new();

            foreach (var o in ordine)
            {
                var ricetta = TrovaRicetta(o.Key);

                if (ricetta == null)
                    continue;

                var ingredienti = EstraiIngredienti(ricetta);

                foreach (var ing in ingredienti)
                {
                    if (!dispensa.Contains(ing))
                        spesa.Add(ing);
                }
            }

            foreach (var s in spesa)
                listBoxSpesa.Items.Add(s);
        }

        // ============================
        // CUCINATO
        // ============================
        private void btnCucinato_Click(object sender, EventArgs e)
        {
            if (ordine.Count == 0)
            {
                MessageBox.Show("Non ci sono ordini da cucinare.");
                return;
            }

            var primo = ordine.First();

            var ricetta = TrovaRicetta(primo.Key);

            if (ricetta == null)
            {
                MessageBox.Show("Ricetta non trovata.");
                return;
            }

            var ingredienti = EstraiIngredienti(ricetta);

            var mancanti = ingredienti.Where(i => !dispensa.Contains(i)).ToList();

            if (mancanti.Count > 0)
            {
                MessageBox.Show(
                    "Non puoi cucinare, mancano:\n" + string.Join("\n", mancanti),
                    "Ingredienti mancanti",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
                return;
            }

            foreach (var ing in ingredienti)
            {
                string i = ing.Trim().ToLower();
                dispensa.RemoveAll(x => x == i);
            }

            File.WriteAllLines(fileDispensa, dispensa);

            if (primo.Value <= 1)
                ordine.Remove(primo.Key);
            else
                ordine[primo.Key]--;

            AggiornaUI();

            btnSpesa_Click(this, EventArgs.Empty);

            MessageBox.Show($"Hai cucinato: {primo.Key}!", "Successo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // ============================
        // AGGIUNGI INGREDIENTI
        // ============================
        private void btnAggiungi_Click(object sender, EventArgs e)
        {
            if (listBoxSpesa.Items.Count == 0)
            {
                MessageBox.Show("La lista della spesa � vuota.");
                return;
            }

            int aggiunti = 0;

            foreach (var item in listBoxSpesa.Items)
            {
                string ingrediente = item.ToString().Trim().ToLower();

                if (!dispensa.Contains(ingrediente))
                {
                    dispensa.Add(ingrediente);
                    aggiunti++;
                }
            }

            File.WriteAllLines(fileDispensa, dispensa);

            MessageBox.Show($"Aggiunti {aggiunti} ingredienti alla dispensa.");

            listBoxSpesa.Items.Clear();
        }


        // ============================
        // TROVA RICETTA
        // ============================
        string? TrovaRicetta(string nome)
        {
            string target = nome.ToLower().Trim();

            var r1 = ricette.FirstOrDefault(r =>
            {
                string titolo = r.Split('.')[0].Trim().ToLower();
                return titolo == target;
            });

            if (r1 != null)
                return r1;

            var r2 = ricette.FirstOrDefault(r =>
            {
                string titolo = r.Split('.')[0].Trim().ToLower();
                return titolo.Contains(target) || target.Contains(titolo);
            });

            return r2;
        }

        // ============================
        // ESTRAZIONE INGREDIENTI
        // ============================
        List<string> EstraiIngredienti(string r)
        {
            int start = r.IndexOf("Ingredienti:");
            int end = r.IndexOf("Preparazione:");

            if (start == -1 || end == -1)
                return new List<string>();

            start += "Ingredienti:".Length;

            return r.Substring(start, end - start)
                .Split(',')
                .Select(x => x.Trim().ToLower())
                .Where(x => x.Length > 0)
                .ToList();
        }

        private void btnAggiornaOrdini_Click(object sender, EventArgs e)
        {
            LeggiOrdine();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}